create function upd_timestamp()
  returns trigger
language plpgsql
as $$
begin
  new.update_time = current_timestamp;
  return new;
end
$$;

